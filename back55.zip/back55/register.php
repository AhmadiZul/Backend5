<?php 

include 'config.php';

error_reporting(0);

session_start();

if (isset($_SESSION['username'])) {
    header("Location: login.php");
}

if (isset($_POST['submit'])) {
	$username = $_POST['username'];
	$email = $_POST['email'];
	$level = $_POST['level'];
	$password = md5($_POST['password']);
	$cpassword = md5($_POST['cpassword']);

	if ($password == $cpassword) {
		$sql = "SELECT * FROM users WHERE email='$email'";
		$result = mysqli_query($conn, $sql);
	if (!$result->num_rows > 0) {
			$sql = "INSERT INTO users (username, email, level, password)
					VALUES ('$username', '$email','$level', '$password')";
			$result = mysqli_query($conn, $sql);
	if ($result) {
				echo "<script>alert('Kamu telah Terdaftar.')</script>";
				$username = "";
				$email = "";
				$level ="";
				$_POST['password'] = "";
				$_POST['cpassword'] = "";
	} else {
				echo "<script>alert('ada kesalahan silahkan coba lagi.')</script>";
		}
	} else {
			echo "<script>alert(' Email Sudah di pakai yaa, silahkan buat lagi.')</script>";
		}
		
	} else {
		echo "<script>alert('Password tidak sama mohon di ulangi kembali.')</script>";
	}
}

?>

<!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <title>Halaman Login</title>
    <link rel="stylesheet" href="style.css" media="screen" title="no title">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
    
    <form action="" method="post">
        <div class="login">

          <div class="avatar">
            <i class="fa fa-user"></i>
          </div>

          <h2>Halaman Registrasi</h2>

          <div class="box-login">
            <i class="fas fa-envelope-open-text"></i>
            <input type="text" name="username" placeholder="Username" value="<?php echo $username; ?>" required>
          </div>

		  <div class="box-login">
            <i class="fas fa-envelope-open-text"></i>
            <input type="email" name="email" placeholder="Email" value="<?php echo $email; ?>" required>
          </div>

		  <div class="input-group">
						<select name="level" class="form-control" value="<?php echo $level; ?>" required>
							<option value="">Pilih Level User</option>
							<option value="Admin">Administrator</option>
							<option value="Pengguna">Pengguna</option>
						</select>
		  </div>

		  <div class="box-login">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" placeholder="Password" value="<?php echo $_POST['password']; ?>" required>
          </div>

		  <div class="box-login">
            <i class="fas fa-lock"></i>
            <input type="password" name="cpassword" placeholder="Config Password" value="<?php echo $_POST['cpassword']; ?>" required>
          </div>

          

          <button type="submit" name="submit" class="btn-login">Registrasi</button><br>
          <p class="login-register-text">Sudah Mempunyai akun?<a href="login.php">Login Disini</a>.</p>
          
        </div>
    </form>
  </head>
  </html>