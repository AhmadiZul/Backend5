<?php 

include 'config.php';

session_start();

error_reporting(0);

if (isset($_SESSION['username'])) {
    header("Location: admin/index.php");
}

if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = md5($_POST['password']);

	$sql = "SELECT * FROM users WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['username'] = $row['username'];
		header("Location: admin/index.php");
	} else {
		echo "<script>alert('Email Atau Password Anda Salah')</script>";
	}
}

?>

<!DOCTYPE html>
  <html>
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE-edge">
    <title>Halaman Login</title>
    <link rel="stylesheet" href="style.css" media="screen" title="no title">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.6.3/css/all.css">
    
  <div class="container">  
    <form action="" method="post" class="login-email">
        <div class="login">

          <div class="avatar">
            <i class="fa fa-user"></i>
          </div>

          <h2>Halaman Login</h2>

          <div class="box-login">
            <i class="fas fa-envelope-open-text"></i>
            <input type="email" name="email" placeholder="Email" value="<?php echo $email; ?>" required>
          </div>

          <div class="box-login">
            <i class="fas fa-lock"></i>
            <input type="password" name="password" placeholder="Password"  value="<?php echo $_POST['password']; ?>" required>
          </div>

          <button type="submit" name="submit" class="btn-login">Login</button><br>
          <p class="login-register-text">Tidak Mempunyai akun?<a href="register.php">Daftar Disini</a>.</p>
          
        </div>
    </form>
  </div>
  </head>
  </html>